# Assignment 3: OpenMP (hpcgp000)

## Program layout
The program consists of one file named **disitance_cell.c**. The program requires the non-standard include file “omp.h” to enable parallelisation with OpenMP. “time.h” is used to measure the runtime of the program.

The program takes one input argument: the number of threads that will be used in the parallelisation (tn). The output from running the program is a sorted list of distances with corresponding frequencies, which is  written as a standard output.

The main restriction on the implementation of the solution is that the program may not consume more than 1GiBi byte of memory at any time. This problem was solved by only allocating memory less than the limit (while also accounting for space needed for results and such), and loading in chunks of the file and performing the calculations on the data of two chunks at a time (using two pointers to the file with the cell data). The data from the files is not guaranteed to create even chunks, which creates a special case when the “rest” is calculated.

To perform these calculations in chunks, the length of the data file was required. This information was gathered with the use of the functions **fseek** and **ftell**. The maximum size of the allocated memory for the chunks was determined experimentally to keep the size less that the size of the cache. The size of each chunk was then calculated with these things in mind, and the lines that would not fit in any of these chunks was called the “rest”.

To loop over each cell and compare it to every other cell in the data set, eight for loops were required. The following code block displays the pseudo code of the layout:

readCh()

    for(i=0 -> chSz)

        read data in block with pointer

comp_and_store(ch1,ch2)

    for(i=0 -> chSz)

        for(j=i -> chSz)

            Dist = calcdist(ch1(i),ch2(j))

            freq[Dist]++
pragma

for(i = 0 -> chNr)

    ch1 = readch()

    comp_and_store(ch1,ch1)

    Pointer2pos = Pointer1pos

    for(j = i+1 -> chNr)

        ch2 = readch()

        comp_and_store(ch1,ch2)

The program loops over each chunk, first reading with pointer 1 and  comparing this chunk to itself. Next, pointer two reads the next chunk and compares it to the chunk read by pointer 1. Pointer two then moves to the next chunk so that every cell can be compared to those in chunk 1. When everything has been compared with chunk 1, pointer 1 is moved to the next chunk is read. The same procedure occurs, with pointer 2 always starting on the chunk after the one read by pointer 1.

In the final part of the program, the results are printed. This is done by looping over each possible distance and only printing the ones where the frequency is not zero.

## Performance
The following presents performance test on system Gantenbein:

file : e4 Flag: -t1
T_read = 0.0138s    T_calc = 0.152s    T_tot = 0.169s

file : e5 Flag: -t5
T_read = 0.295s    T_calc = 3.85s        T_tot = 4.166s

file : e5 Flag: -t10
T_read = 0.301s    T_calc = 1.96s        T_tot=2.266s

file : e5 Flag: -t20
T_read = 0.377s    T_calc = 1.49s        T_tot=1.868s

A few things have been done for performance. To start with the number of reads and comparisons in the program are exactly the minimum amount of comparisons possible.

The read is done by the function fscan() it is possible that further performance could be gained by changing it to the faster function fread().

To compare two cells and store the result the distance is calculated and converted to an int used as an index to an freq. array long enough to store all possible distances (indexes).






